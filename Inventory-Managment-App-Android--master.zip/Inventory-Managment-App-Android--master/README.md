# Inventory-Managment-App-Android-
This software maintains products by entering information such as name, product id, buy rate, and product description. 

# Screen Shot
![image](https://github.com/ANIKETH232323/Inventory-Managment-App-Android-/assets/102458123/9e889519-12d4-4b7d-be01-7ad4e8d304ec)

![image](https://github.com/ANIKETH232323/Inventory-Managment-App-Android-/assets/102458123/0b4accf0-ca50-4deb-9daa-e445d75496e8)

![image](https://github.com/ANIKETH232323/Inventory-Managment-App-Android-/assets/102458123/8123c415-8330-47dc-980c-8964499d5245)

![image](https://github.com/ANIKETH232323/Inventory-Managment-App-Android-/assets/102458123/36f53ea0-ecac-4d00-a97e-9320e7580274)

![image](https://github.com/ANIKETH232323/Inventory-Managment-App-Android-/assets/102458123/9fc70a27-2944-4a8c-b59a-f2aeaa4be17e)

![image](https://github.com/ANIKETH232323/Inventory-Managment-App-Android-/assets/102458123/7b016e83-8408-4221-aabd-1d546547959d)

![image](https://github.com/ANIKETH232323/Inventory-Managment-App-Android-/assets/102458123/89aa75dd-c26f-40a6-a5c1-2263bf7f4878)

![image](https://github.com/ANIKETH232323/Inventory-Managment-App-Android-/assets/102458123/d09cc953-7566-4362-8538-09213b5e8672)




